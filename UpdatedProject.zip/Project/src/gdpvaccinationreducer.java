//By Qiao Xin
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.io.DoubleWritable;

public class gdpvaccinationreducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable>{
	DoubleWritable vaccinationRate = new DoubleWritable();  
	@Override 
	protected void reduce(Text key, Iterable<DoubleWritable>values,Reducer<Text,DoubleWritable,Text,DoubleWritable>.Context context)
	throws IOException, InterruptedException{
		double total = 0;
		double overall =0;	
		double num= 0;
		
		//calculate the total vaccination rate in the same income group
		for(DoubleWritable value:values) {
			total += value.get();
			//calculate the number of country in the same income group
			num +=1;
		}
		//to find the average vaccination rate for that income group
		overall = total/num;
		vaccinationRate.set(overall);
		context.write(key,vaccinationRate);
	}

}
