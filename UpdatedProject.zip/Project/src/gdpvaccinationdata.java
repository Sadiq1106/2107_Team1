//By Qiao Xin
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.DoubleWritable;

public class gdpvaccinationdata extends Mapper<LongWritable,Text, Text, DoubleWritable> {
	//For vaccination data
	Text income = new Text();
	IntWritable one = new IntWritable(1);
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable,Text,Text,DoubleWritable>.Context context)
			throws IOException, InterruptedException{
		//Split the data into column
		String[] parts = value.toString().split(",");
	
		String incomegroup;
		//Convert the vaccination rate from string to double
		double rate = Double.parseDouble(parts[5]);
		DoubleWritable total = new DoubleWritable(rate);
	
		//Check that the income group column is not empty 
		if(parts[6]!=null) {
			incomegroup = parts[6].trim();
			if(incomegroup!=null && !incomegroup.isEmpty()) {
				income.set(incomegroup);
				//set the income group as key and the total vaccination rate as value
				context.write(income,total);
			}
		}
	}
}
