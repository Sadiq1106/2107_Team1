//By Jia En
//country-covid1.csv
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
public class totalCaseMapper extends Mapper<LongWritable,Text, Text, IntWritable> {
	Text regionValue = new Text();
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable,Text,Text,IntWritable>.Context context)
			throws IOException, InterruptedException{
		String[] parts = value.toString().split(",");
		String region;
		
		IntWritable total = new IntWritable(Integer.parseInt(parts[1]));
	
		if(parts[14]!=null) {
			//set the Region name as regionValue
			region = parts[14].trim();	
			if(region!=null && !region.isEmpty()) {
				regionValue.set(region);	
				if(total != null)
				{
					//calculating the total number of cases per region
					IntWritable totalValue = total;
					context.write(regionValue,totalValue);
				}
				
			}
		}
	}
}
